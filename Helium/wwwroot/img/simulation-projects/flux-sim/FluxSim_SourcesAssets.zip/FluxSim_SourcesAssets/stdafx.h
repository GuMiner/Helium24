// Precompiled header file.
#define SFML_STATIC

// STL includes
#include <cstdlib>
#include <iostream>

#include <fstream>

#include <vector>
#include <deque>
#include <map>

#include <string>
#include <sstream>

#include <limits>

// Sfml includes
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

// Eigen includes
#include <Eigen/Sparse>
#include <Eigen/IterativeLinearSolvers>