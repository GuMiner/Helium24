#pragma once

#include "stdafx.h"

class PhysicsData
{
public:
    sf::Uint32 materialIdx;

    float temperature;
    float lastTemp;

    bool isFixed;
    bool isInsulator;

    PhysicsData(void);
    PhysicsData(float temp, sf::Uint32 mat, bool fixed, bool insulator);

    void IterateTemperature(float newTemp);
};