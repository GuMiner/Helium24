#include "stdafx.h"
#include "ThermalSim.h"

ThermalSim::ThermalSim(void)
{
    gamma = 0.001f; //gamma_total = pcx^2/(4kdeltatheta) // gamma = x^2/delta theta
}

float ThermalSim::SpeedChange(bool up, bool down)
{
    if (up)
    {
        gamma *= 10.0f;
    }
    if (down)
    {
        gamma *= 0.10f;
    }
    return gamma;
}

void ThermalSim::Simulate(sf::Time& timeStep, std::vector<std::vector<PhysicsData>>& dataPoints, std::vector<MaterialData>& materials, bool doRefresh)
{
    //sf::Clock computeClock;
    // V1: No time dependence (ie, find the SS solution), guaranteed complete boundary conditions, no insulation.

    if (equationIndexes.size() != dataPoints.size() || doRefresh)
    {
        equationCount = 0;
        equationIndexes.clear();
        for (sf::Uint32 i = 0; i < dataPoints.size(); i++)
        {
            equationIndexes.push_back(std::vector<sf::Int32>());
            for (sf::Uint32 j = 0; j < dataPoints[i].size(); j++)
            {
                if (!dataPoints[i][j].isFixed)
                {
                    equationIndexes[i].push_back(equationCount);
                    ++equationCount;

                }
                else
                {
                    equationIndexes[i].push_back(-1);
                }
            }
        }

        gridMatrix = Eigen::SparseMatrix<float>(equationCount, equationCount);
        bVector = Eigen::VectorXf(equationCount);
        temperatureResultVector = Eigen::VectorXf(equationCount);
    }

    // Generate the temporary sparse points and the b and T vectors.
    sparsePoints.clear();
    for (sf::Uint32 i = 0; i < dataPoints.size(); i++)
    {
        for (sf::Uint32 j = 0; j < dataPoints[i].size(); j++)
        {
            sf::Int32 equationIdx = equationIndexes[i][j];
            if (equationIdx != -1)
            {
                // Load TRV with the current temperature as an initial guess.
                temperatureResultVector[equationIdx] = dataPoints[i][j].temperature;
                sf::Int32 eUp, eDown, eLeft, eRight;
                if (dataPoints[i][j].isInsulator)
                {
                    // Special handling here to duplicate the opposite temperature index.
                    if (i == 0)
                    {
                        if (j == 0)
                        {
                            eDown = equationIndexes[i][j + 1];
                            eUp = eDown;
                        }
                        else if (j == dataPoints[0].size() - 1)
                        {
                            eUp = equationIndexes[i][j - 1];
                            eDown = eUp;
                        }
                        else
                        {
                            eUp = equationIndexes[i][j - 1];
                            eDown = equationIndexes[i][j + 1];
                        }

                        eRight = equationIndexes[i + 1][j];
                        eLeft = eRight;
                    }
                    else if (i == dataPoints.size() - 1)
                    {
                        if (j == 0)
                        {
                            eDown = equationIndexes[i][j + 1];
                            eUp = eDown;
                        }
                        else if (j == dataPoints[0].size() - 1)
                        {
                            eUp = equationIndexes[i][j - 1];
                            eDown = eUp;
                        }
                        else
                        {
                            eUp = equationIndexes[i][j - 1];
                            eDown = equationIndexes[i][j + 1];
                        }
                            
                            
                        eLeft = equationIndexes[i - 1][j];
                        eRight = eLeft;
                            
                    }
                    else
                    {
                        if (j == 0)
                        {
                            eDown = equationIndexes[i][j + 1];
                            eLeft = equationIndexes[i - 1][j];
                            eRight = equationIndexes[i + 1][j];
                            eUp = eDown;
                        }
                        else if (j == dataPoints[0].size() - 1)
                        {
                            eUp = equationIndexes[i][j - 1];
                            eLeft = equationIndexes[i - 1][j];
                            eRight = equationIndexes[i + 1][j];
                            eDown = eUp;
                        }
                    }
                }
                else
                {
                    // Find the equation indexes of the surrounding four points.
                    eUp = equationIndexes[i][j - 1];
                    eDown = equationIndexes[i][j + 1];
                    eLeft = equationIndexes[i - 1][j];
                    eRight = equationIndexes[i + 1][j];
                }

                bVector[equationIdx] = 0;
                if (eUp != -1)
                {
                    sparsePoints.push_back(Eigen::Triplet<float>(equationIdx, eUp, -0.25)); // T_n - delta y
                }
                else
                {
                    bVector[equationIdx] += 0.25f*dataPoints[i][j - 1].temperature;
                }

                if (eDown != -1)
                {
                    sparsePoints.push_back(Eigen::Triplet<float>(equationIdx, eDown, -0.25)); // T_n + delta y
                }
                else
                {
                    bVector[equationIdx] += 0.25f*dataPoints[i][j + 1].temperature;
                }

                if (eLeft != -1)
                {
                    sparsePoints.push_back(Eigen::Triplet<float>(equationIdx, eLeft, -0.25)); // T_n - delta x
                }
                else
                {
                    bVector[equationIdx] += 0.25f*dataPoints[i - 1][j].temperature;
                }

                if (eRight != -1)
                {
                    sparsePoints.push_back(Eigen::Triplet<float>(equationIdx, eRight, -0.25)); // T_n + delta x
                }
                else
                {
                    bVector[equationIdx] += 0.25f*dataPoints[i + 1][j].temperature;
                }

                // V2: Time varying
                MaterialData& material = materials[dataPoints[i][j].materialIdx];
                float gammaEff = gamma*material.GetDensity(dataPoints[i][j].temperature)*material.GetHeatCapacity(dataPoints[i][j].temperature)/material.GetThermalConductivity(dataPoints[i][j].temperature);
                bVector[equationIdx] += gammaEff*dataPoints[i][j].lastTemp;

                // Also need
                sparsePoints.push_back(Eigen::Triplet<float>(equationIdx, equationIdx, 1 + gammaEff)); // T_n
            }
        }
    }
    
    gridMatrix.setFromTriplets(sparsePoints.begin(), sparsePoints.end());

    //// Solve
    
    // Faster by ~4 sec than the Conjugate gradient method ... adding IncompleteLUT as a preconditioner
    //  speeds up iteration by 4 sec also (6 sec vs 10), but then keeps subsequent iterations at 6 sec.
    Eigen::BiCGSTAB<Eigen::SparseMatrix<float>> solver;

    // Precondition
    solver.compute(gridMatrix);
    if (solver.info() != Eigen::Success)
    {
        std::cout << "Solver could not precondition the temperature matrix for solving!" << std::endl;
    }

    // Iterate
    sf::Int32 iterations = 0;
    do
    {
        temperatureResultVector = solver.solveWithGuess(bVector, temperatureResultVector);
        ++iterations;
    }
    while (solver.info() != Eigen::Success && iterations < 1000);
    
    // Copy the results back into the data points.
    for (sf::Uint32 i = 0; i < dataPoints.size(); i++)
    {
        for (sf::Uint32 j = 0; j < dataPoints[i].size(); j++)
        {
            if (equationIndexes[i][j] != -1)
            {
                dataPoints[i][j].IterateTemperature(temperatureResultVector[equationIndexes[i][j]]);
            }
        }
    }
    
    //std::cout << "Compute time was " << computeClock.restart().asSeconds() << " seconds." << std::endl;
}