#include "stdafx.h"
#include "FpsDisplay.h"

void FpsDisplay::Update(sf::Time& timeDelta)
{
    lastTen.push_back((sf::Int32)(1000000.0f/(float)timeDelta.asMicroseconds()));

    if (lastTen.size() > 5)
    {
        lastTen.pop_front();
    }
}

std::string FpsDisplay::GetAverageFPS(void)
{
    sf::Int32 sum = 0;
    for (std::deque<sf::Int32>::const_iterator iter = lastTen.cbegin(); iter != lastTen.cend(); ++iter)
    {
        sum += *iter;
    }

    std::stringstream fpsStream;
    fpsStream << sum/lastTen.size() << "." << (10*sum)/lastTen.size() - 10*(sum/lastTen.size());

    return fpsStream.str();
}

std::string FpsDisplay::GetText(void)
{
    std::stringstream stream;
    stream << "FPS: " << GetAverageFPS();
    return stream.str();
}