#include "stdafx.h"
#include "PhysicsData.h"

PhysicsData::PhysicsData(void)
{
}

PhysicsData::PhysicsData(float temp, sf::Uint32 mat, bool fixed, bool insulator)
{
    temperature = temp;
    lastTemp = temp;

    isFixed = fixed;
    isInsulator = insulator;

    materialIdx = mat;

    if (fixed && insulator)
    {
        std::cout << "Warning: A cell cannot have fixed temperature and be an insulator!" << std::endl;
        std::cout << "Check your initial condition setting!" << std::endl;
    }
}

// Copy in the new temperature and save the old one for future reference.
void PhysicsData::IterateTemperature(float newTemp)
{
    lastTemp = temperature;
    temperature = newTemp;
}