#include "stdafx.h"
#include "MaterialDataPoint.h"

MaterialDataPoint::MaterialDataPoint()
{
}

MaterialDataPoint::MaterialDataPoint(float temp, float hC, float tC, float den)
{
    temperature = temp;
    heatCapacity = hC;
    thermalConductivity = tC;
    density = den;
}

// Linear interpolation methods The assumption is that other is > this.
float MaterialDataPoint::InterpolateHeatCapacity(MaterialDataPoint& other, float temp)
{
    float fraction = (temp - temperature)/(other.temperature - temperature);
    return heatCapacity + fraction*(other.heatCapacity - heatCapacity);
}
float MaterialDataPoint::InterpolateThermalConductivity(MaterialDataPoint& other, float temp)
{
    float fraction = (temp - temperature)/(other.temperature - temperature);
    return thermalConductivity + fraction*(other.thermalConductivity - thermalConductivity);
}
float MaterialDataPoint::InterpolateDensity(MaterialDataPoint& other, float temp)
{
    float fraction = (temp - temperature)/(other.temperature - temperature);
    return density + fraction*(other.density - density);
}

// Overloaded comparison operators
bool MaterialDataPoint::operator>(MaterialDataPoint& other)
{
    return !operator<(other);
}
bool MaterialDataPoint::operator<(MaterialDataPoint& other)
{
    return temperature < other.temperature;
}