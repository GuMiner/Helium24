#pragma once

#include "stdafx.h"
#include "PhysicsData.h"
#include "MaterialData.h"

class ThermalSim
{
    sf::Int32 equationCount;
    std::vector<std::vector<sf::Int32>> equationIndexes;

    Eigen::SparseMatrix<float> gridMatrix;
    Eigen::VectorXf bVector, temperatureResultVector;
    std::vector<Eigen::Triplet<float>> sparsePoints;

    Eigen::BiCGSTAB<Eigen::SparseMatrix<float>> solver;

    // Time scaling factor.
    float gamma;

public:
    ThermalSim(void);
    float SpeedChange(bool up, bool down);
    void Simulate(sf::Time& timeStep, std::vector<std::vector<PhysicsData>>& dataPoints, std::vector<MaterialData>& materials, bool doRefresh);

};

