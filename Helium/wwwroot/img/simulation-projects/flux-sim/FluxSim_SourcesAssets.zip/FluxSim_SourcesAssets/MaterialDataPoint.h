#pragma once
class MaterialDataPoint
{
public:
    float temperature;

    float heatCapacity;
    float thermalConductivity;
    float density;

    float InterpolateHeatCapacity(MaterialDataPoint& other, float temp);
    float InterpolateThermalConductivity(MaterialDataPoint& other, float temp);
    float InterpolateDensity(MaterialDataPoint& other, float temp);

    bool operator>(MaterialDataPoint& other);
    bool operator<(MaterialDataPoint& other);

    MaterialDataPoint();
    MaterialDataPoint(float temp, float hC, float tC, float dens);
};

