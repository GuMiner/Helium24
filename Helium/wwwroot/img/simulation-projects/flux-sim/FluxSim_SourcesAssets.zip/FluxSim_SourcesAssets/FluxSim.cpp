#include "stdafx.h"
#include "FluxSim.h"

// Different includes are required for debug builds. 
#ifndef _DEBUG
    #pragma comment(lib, "lib/sfml-window-s.lib")
    #pragma comment(lib, "lib/sfml-graphics-s.lib")
    #pragma comment(lib, "lib/sfml-system-s.lib")
#else
    #pragma comment (lib, "lib/sfml-window-s-d.lib")
    #pragma comment(lib, "lib/sfml-graphics-s-d.lib")
    #pragma comment(lib, "lib/sfml-system-s-d.lib")
#endif

// Constructs a simple text item for use in drawing.
sf::Text FluxSim::GetText(sf::Uint32 size, sf::Uint32 style, sf::Color color)
{
    sf::Text newText;
    newText.setFont(simFont);
    newText.setCharacterSize(size);
    newText.setStyle(style);
    newText.setColor(color);

    return newText;
}

// Sets up the remaining text parameters in preparation for drawing.
sf::Text& FluxSim::PrepareText(sf::Text& textIn, sf::Vector2f& pos, std::string& text)
{
    textIn.setPosition(pos);
    textIn.setString(text);
    return textIn;
}

bool FluxSim::Initialize(void)
{
    if (!simFont.loadFromFile("assets/Minecraftia.ttf"))
    {
        std::cout << "Error loading simulation font!" << std::endl;
        return false;
    }

    matData.push_back(MaterialData("assets/AluminumData.txt"));
    for (sf::Uint32 i = 0; i < matData.size(); i++)
    {
        if (!matData[i].isValid)
        {
            return false;
        }
    }

    windowSize.x = 1366;
    windowSize.y = 768;
    frameLimit = 60;
    name = std::string("Heat Flux Simulator");

    return true;
}

void FluxSim::LoadSimulation(SimType type)
{
    switch(type)
    {
    case HOT_WALLS:
        // Walls set at fixed temperature.
        simGrid.clear();
        for (sf::Uint32 i = 0; i < windowSize.x/SimDisplay::SCALE_FACTOR; i++)
        {
            // Some preoptimization on the size of the array.
            simGrid.push_back(std::vector<PhysicsData>(windowSize.y/SimDisplay::SCALE_FACTOR));
            for (sf::Uint32 j = 0; j < windowSize.y/SimDisplay::SCALE_FACTOR; j++)
            {
                // Make the outer edges at 200 F
                bool isEdge = (i == 0 || j == 0 || i == windowSize.x/SimDisplay::SCALE_FACTOR - 1 || j == windowSize.y/SimDisplay::SCALE_FACTOR - 1);
                simGrid[i][j] = PhysicsData(isEdge ? 200.0f : 200.0f + rand() % 100, 0, isEdge, false);
            }
        }
        return;
    case HOT_SIDE:
        // One wall set at a temp, all others insulated.
        simGrid.clear();
        for (sf::Uint32 i = 0; i < windowSize.x/SimDisplay::SCALE_FACTOR; i++)
        {
            // Some preoptimization on the size of the array.
            simGrid.push_back(std::vector<PhysicsData>(windowSize.y/SimDisplay::SCALE_FACTOR));
            for (sf::Uint32 j = 0; j < windowSize.y/SimDisplay::SCALE_FACTOR; j++)
            {
                // Make the left edge at 200, the rest at random (insulated) temperatures.
                bool isEdge = (i == 0 || j == 0 || i == windowSize.x/SimDisplay::SCALE_FACTOR - 1 || j == windowSize.y/SimDisplay::SCALE_FACTOR - 1);
                bool isLeftEdge = (i == 0);
                simGrid[i][j] = PhysicsData(isLeftEdge ? 200.0f : 200.0f + rand() % 100, 0, isLeftEdge, isEdge && !isLeftEdge);
            }
        }
        return;
    case HOT_WALLS_AND_ROD:
        // Walls set at fixed temperature with rod also at fixed temp in the middle.
        simGrid.clear();
        for (sf::Uint32 i = 0; i < windowSize.x/SimDisplay::SCALE_FACTOR; i++)
        {
            // Some preoptimization on the size of the array.
            simGrid.push_back(std::vector<PhysicsData>(windowSize.y/SimDisplay::SCALE_FACTOR));
            for (sf::Uint32 j = 0; j < windowSize.y/SimDisplay::SCALE_FACTOR; j++)
            {
                // Make the outer edges at 200 F, inner at 300
                bool isEdge = (i == 0 || j == 0 || i == windowSize.x/SimDisplay::SCALE_FACTOR - 1 || j == windowSize.y/SimDisplay::SCALE_FACTOR - 1);
                bool isCenter = (i > windowSize.x/(4*SimDisplay::SCALE_FACTOR) && i < windowSize.x*3/(4*SimDisplay::SCALE_FACTOR) && j > windowSize.y/(4*SimDisplay::SCALE_FACTOR) && j < windowSize.y*3/(4*SimDisplay::SCALE_FACTOR));
                simGrid[i][j] = PhysicsData(isEdge ? 200.0f : (isCenter ? 300.0f : 200.0f + rand() % 100), 0, isEdge || isCenter, false);
            }
        }
        return;
    case HOT_WALLS_FIXED_POINTS:
        simGrid.clear();
        for (sf::Uint32 i = 0; i < windowSize.x/SimDisplay::SCALE_FACTOR; i++)
        {
            // Some preoptimization on the size of the array.
            simGrid.push_back(std::vector<PhysicsData>(windowSize.y/SimDisplay::SCALE_FACTOR));
            for (sf::Uint32 j = 0; j < windowSize.y/SimDisplay::SCALE_FACTOR; j++)
            {
                // Make the outer edges at 200 F
                bool isEdge = (i == 0 || j == 0 || i == windowSize.x/SimDisplay::SCALE_FACTOR - 1 || j == windowSize.y/SimDisplay::SCALE_FACTOR - 1);
                bool isCenter = i % 8 == 0 && j % 8 == 0;
                simGrid[i][j] = PhysicsData(isEdge || isCenter ? 200.0f : 200.0f + rand() % 100, 0, isEdge || isCenter, false);
            }
        }
        return;
    case HOT_WALLS_INSULATED_POINTS:
        simGrid.clear();
        for (sf::Uint32 i = 0; i < windowSize.x/SimDisplay::SCALE_FACTOR; i++)
        {
            // Some preoptimization on the size of the array.
            simGrid.push_back(std::vector<PhysicsData>(windowSize.y/SimDisplay::SCALE_FACTOR));
            for (sf::Uint32 j = 0; j < windowSize.y/SimDisplay::SCALE_FACTOR; j++)
            {
                // Make the outer edges at 200 F
                bool isEdge = (i == 0 || j == 0 || i == windowSize.x/SimDisplay::SCALE_FACTOR - 1 || j == windowSize.y/SimDisplay::SCALE_FACTOR - 1);
                bool isCenter = i % 8 == 0 && j % 8 == 0;
                simGrid[i][j] = PhysicsData(isEdge ? 200.0f : 200.0f + rand() % 100, 0, isEdge, isCenter && !isEdge);
            }
        }
        return;
    case CONTINUOUS_FIXED_WALLS:
        simGrid.clear();
        for (sf::Uint32 i = 0; i < windowSize.x/SimDisplay::SCALE_FACTOR; i++)
        {
            // Some preoptimization on the size of the array.
            simGrid.push_back(std::vector<PhysicsData>(windowSize.y/SimDisplay::SCALE_FACTOR));
            for (sf::Uint32 j = 0; j < windowSize.y/SimDisplay::SCALE_FACTOR; j++)
            {
                // Make the outer edges at 200 F, inner at 300
                bool isEdge = (i == 0 || j == 0 || i == windowSize.x/SimDisplay::SCALE_FACTOR - 1 || j == windowSize.y/SimDisplay::SCALE_FACTOR - 1);
                simGrid[i][j] = PhysicsData(isEdge ? 200.0f + (float)i*100.0f/(float)(windowSize.x/SimDisplay::SCALE_FACTOR) : 200.0f + rand() % 100, 0, isEdge, false);
            }
        }
        return;
    default:
        return;
    }
}
void FluxSim::BeginSimulation(void)
{
    // Setup the window
    sf::Uint32 style = sf::Style::Titlebar | sf::Style::Close;

    sf::RenderWindow window(sf::VideoMode(windowSize.x/SimDisplay::SCALE_FACTOR, windowSize.y/SimDisplay::SCALE_FACTOR), name, sf::Style::Titlebar | sf::Style::Close | sf::Style::Resize);
    window.setFramerateLimit(frameLimit);

    // Setup our simulation area.
    bool doRefresh = true;
    LoadSimulation(SimType::HOT_WALLS);

    // Setup the single-press key handlers.
    bool speedupOneShot = false;
    bool speeddownOneShot = false;
    bool colorChangeOneShot = false;
    
    // Setup the simulation change key handlers.
    const sf::Uint32 NUM_NUM_KEYS = 10;
    bool numKeyOneShots [NUM_NUM_KEYS];
    sf::Keyboard::Key numKeyKeys [NUM_NUM_KEYS];
    for (sf::Uint32 i = 0; i < NUM_NUM_KEYS; i++)
    {
        numKeyOneShots[i] = false;
        numKeyKeys[i] = (sf::Keyboard::Key)(sf::Keyboard::Key::Num1 + i);
        if (i == NUM_NUM_KEYS - 1)
        {
            // Zero is out-of-order numerically on a US keyboard.
            numKeyKeys[i] = sf::Keyboard::Num0;
        }
    }

    sf::Clock fpsTimer;
    sf::Event globalEvents;
    while (window.isOpen())
    {
        // Handle events from the window.
        while (window.pollEvent(globalEvents))
        {
            switch(globalEvents.type)
            {
                case sf::Event::Closed:
                    window.close();
                    break;
                case sf::Event::Resized:
                    windowSize.x = globalEvents.size.width;
                    windowSize.y = globalEvents.size.height;
                    break;
            }
        }

        //// Perform update tasks.
        sf::Time elapsedTime = fpsTimer.restart();

        // Quit on a q.
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Q))
        {
            window.close();
            break;
        }

        // Update the speed counter
        std::stringstream speedString;
        speedString << simUpdater.SpeedChange(false, false);

        const sf::Keyboard::Key UP_KEY = sf::Keyboard::Up;
        const sf::Keyboard::Key DOWN_KEY = sf::Keyboard::Down;
        const sf::Keyboard::Key COLOR_KEY = sf::Keyboard::T;
        if (!speedupOneShot && sf::Keyboard::isKeyPressed(UP_KEY))
        {
            speedupOneShot = true;
            simUpdater.SpeedChange(true, false);
        }
        else if (speedupOneShot && !sf::Keyboard::isKeyPressed(UP_KEY))
        {
            speedupOneShot = false;
        }

        if (!speeddownOneShot && sf::Keyboard::isKeyPressed(DOWN_KEY))
        {
            speeddownOneShot = true;
            simUpdater.SpeedChange(false, true);
        }
        else if (speeddownOneShot && !sf::Keyboard::isKeyPressed(DOWN_KEY))
        {
            speeddownOneShot = false;
        }

        // Update the color scheme.
        if (!colorChangeOneShot && sf::Keyboard::isKeyPressed(COLOR_KEY))
        {
            colorChangeOneShot = true;
            simDisplay.FlipColorScheme();
        }
        else if (colorChangeOneShot && !sf::Keyboard::isKeyPressed(COLOR_KEY))
        {
            colorChangeOneShot = false;
        }

        // Update the currently-loaded simulation
        for (sf::Uint32 i = 0; i < NUM_NUM_KEYS; i++)
        {
            if (!numKeyOneShots[i] && sf::Keyboard::isKeyPressed(numKeyKeys[i]))
            {
                LoadSimulation((SimType)i);

                // Resizing the window also changes the view size! We set that back on refresh
                sf::View view = sf::View(sf::FloatRect(0, 0, (float)windowSize.x/SimDisplay::SCALE_FACTOR, (float)windowSize.y/SimDisplay::SCALE_FACTOR));
                window.setView(view);

                doRefresh = true;
                numKeyOneShots[i] = true;
            }
            else if (numKeyOneShots[i] && !sf::Keyboard::isKeyPressed(numKeyKeys[i]))
            {
                numKeyOneShots[i] = false;
            }
        } 

        // Perform the physics simulation
        simUpdater.Simulate(elapsedTime, simGrid, matData, doRefresh);
        doRefresh = false;

        // Update the fps counter.
        fpsDisplay.Update(elapsedTime);

        //// Perform rendering tasks

        // Render the thermal grid
        simDisplay.Render(window, simGrid);

        // Draw the fps counter and current running speed
        window.draw(PrepareText(GetText(9, sf::Text::Style::Regular, sf::Color::Black), sf::Vector2f(10.0f, 10.0f), fpsDisplay.GetText()));
        window.draw(PrepareText(GetText(9, sf::Text::Style::Regular, sf::Color::Black), sf::Vector2f(10.0f, 20.0f), speedString.str()));

        window.display();
    }
}

// Starting point of the simulation program.
int main(int argc, const char* argv[])
{
    std::cout << "Simulation console starting up." << std::endl;

    bool successfulRun = true;
    FluxSim *pSim = new FluxSim();
    if (pSim->Initialize())
    {
        pSim->BeginSimulation();
    }
    else
    {
        successfulRun = false;
    }

    std::cout << "Simulation console terminating." << std::endl;
    sf::sleep(sf::milliseconds(1000));
    
    return successfulRun ? 0 : -1;
}