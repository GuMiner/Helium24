#include "stdafx.h"
#include "MaterialData.h"

MaterialData::MaterialData(std::string filename) : isValid(false)
{
    // Material data is provided in tab-deliminated format, with the name on a single line,
    //  followed by the temperature, thermal conductivity, heat capacity, and density in a row.
    // Units are W, J, g, m, and K only.
    std::ifstream fileInput;
    fileInput.exceptions(std::ifstream::failbit | std::ifstream::badbit);
    try
    {
        fileInput.open(filename);

        // Load the material name.
        std::getline(fileInput, name);

        std::string tempString("");
        std::getline(fileInput, tempString);
        // substr to ignore the tabs.
        while (tempString.substr(0, 5) != "_end_")
        {
            // Break out the material data.
            float temp, tC, hC, den;
            
            std::stringstream tempStream;
            tempStream << tempString;
            tempStream >> temp >> tC >> hC >> den;

            dataPoints.push_back(MaterialDataPoint(temp, hC, tC, den));
            std::getline(fileInput, tempString);
        }

        fileInput.close();
    }
    catch(std::ios_base::failure err)
    {
        std::cout << "Error reading a material data file named " << filename << "!" << std::endl;
        std::cout << "Error message: " << err.what() << std::endl;
        return;
    }

    isValid = true;
}

// Simple linear search (as binary search isn't worth the overhead with 6 data points!)
bool MaterialData::FindMaterialDataPointRange(float temp, MaterialDataPoint *first, MaterialDataPoint *second)
{
    sf::Int32 firstIdx = 0;
    sf::Int32 secondIdx = 1;
    while (secondIdx < (sf::Int32)dataPoints.size())
    {
        if (dataPoints[firstIdx].temperature <= temp && dataPoints[secondIdx].temperature > temp)
        {
            *first = dataPoints[firstIdx];
            *second = dataPoints[secondIdx];
            return true;
        }
        else if (dataPoints[firstIdx].temperature > temp)
        {
            // Too low temperature.
            *first = dataPoints[firstIdx];
            return false;
        }

        ++secondIdx;
    }

    // Too high temperature.
    *first = dataPoints[firstIdx];
    return false;
}

// Grab material properties for a material at a specified temperature.
float MaterialData::GetHeatCapacity(float temp)
{
    MaterialDataPoint first, second;
    if (!FindMaterialDataPointRange(temp, &first, &second))
    {
        std::cout << "Temperature of " << temp << " is out of range for the heat capacity of " << name << "." << std::endl;
        return first.heatCapacity;
    }

    return first.InterpolateHeatCapacity(second, temp);
}
float MaterialData::GetThermalConductivity(float temp)
{
    MaterialDataPoint first, second;
    if (!FindMaterialDataPointRange(temp, &first, &second))
    {
        std::cout << "Temperature of " << temp << " is out of range for the thermal conductivity of " << name << "." << std::endl;
        return first.thermalConductivity;
    }

    return first.InterpolateThermalConductivity(second, temp);
}
float MaterialData::GetDensity(float temp)
{
    MaterialDataPoint first, second;
    if (!FindMaterialDataPointRange(temp, &first, &second))
    {
        std::cout << "Temperature of " << temp << " is out of range for the density of " << name << "." << std::endl;
        return first.density;
    }

    return first.InterpolateDensity(second, temp);
}