#pragma once
#include "stdafx.h"
#include "FpsDisplay.h"
#include "MaterialData.h"
#include "PhysicsData.h"
#include "SimDisplay.h"
#include "ThermalSim.h"

class FluxSim
{
    // Text handling parameters and methods
    sf::Font simFont;
    sf::Text GetText(sf::Uint32 size, sf::Uint32 style, sf::Color color);
    sf::Text& PrepareText(sf::Text& textIn, sf::Vector2f& pos, std::string& text);

    // Window parameters.
    std::string name;
    sf::Vector2u windowSize;
    sf::Uint32 frameLimit;

    FpsDisplay fpsDisplay;

    // Sim data
    std::vector<MaterialData> matData;
    std::vector<std::vector<PhysicsData>> simGrid;

    ThermalSim simUpdater;
    SimDisplay simDisplay;


    enum SimType 
    {
        HOT_WALLS,
        HOT_SIDE,
        HOT_WALLS_AND_ROD,
        HOT_WALLS_FIXED_POINTS,
        HOT_WALLS_INSULATED_POINTS,
        CONTINUOUS_FIXED_WALLS,
        CUSTOM,
        COUNT
    };

    void LoadSimulation(SimType type);
public:
    bool Initialize(void);
    void BeginSimulation(void);
};

