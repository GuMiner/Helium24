#include "stdafx.h"
#include "SimDisplay.h"

SimDisplay::SimDisplay()
{
    size.x = size.y = 0;
    fileIdx = 0;
    isRainbow = true;
}

// Gets a fully-saturated and full brilliance HSV color (H = 0 to 1)
sf::Color SimDisplay::GetHSVtoRGBColor(float h)
{
    // Actual HSV conversion
    if (isRainbow)
    {
        int quadrant = (int)(h * 6.0);
    
        float rem = h * 6.0f - quadrant; // Remainder
        switch (quadrant)
        {
        case 0:
            return sf::Color(255, (sf::Uint8)(rem*255), 0);
        case 1:
            return sf::Color((sf::Uint8)((1 - rem)*255), 255, 0);
        case 2:
            return sf::Color(0, 255, (sf::Uint8)(rem*255));
        case 3:
            return sf::Color(0, (sf::Uint8)((1 - rem)*255), 255);
        case 4:
            return sf::Color((sf::Uint8)(rem*255), 0, 255);
        default:
            return sf::Color(255, 0, (sf::Uint8)((1 - rem)*255));
        }
    }

    // More standard color scheme.
    return sf::Color((sf::Uint8)(255.0f * h), (sf::Uint8)(255.0f * h), (sf::Uint8)(255.0f * h));
}

void SimDisplay::FlipColorScheme(void)
{
    isRainbow = !isRainbow;
}

void SimDisplay::Render(sf::RenderWindow& window, std::vector<std::vector<PhysicsData>>& dataPoints)
{
    bool useImage = true;
    // Reset the size and draw point array if necessary.
    if (dataPoints.size() != size.x || dataPoints[0].size() != size.y)
    {
        std::cout << "(x, y): " << dataPoints.size() << ", " << dataPoints[0].size() << std::endl;
        size.x = dataPoints.size();
        size.y = dataPoints[0].size();
        if (useImage)
        {
            drawImage.create(size.x, size.y);
            drawTexture.create(size.x, size.y);
            drawSprite.setTexture(drawTexture, true);
        }
        else
        {
            drawPoints.clear();
            for (sf::Uint32 i = 0; i < size.x; i++)
            {
                for (sf::Uint32 j = 0; j < size.y; j++)
                {
                    drawPoints.push_back(sf::Vertex(sf::Vector2f((float)i, (float)j + OFFSET_Y)));
                }
            }
        }
    }

    // Find the minimum and maximum temperatures.
    float minTemp = std::numeric_limits<float>::max();
    float maxTemp = std::numeric_limits<float>::min();
    for (sf::Uint32 i = 0; i < size.x; i++)
    {
        for (sf::Uint32 j = 0; j < size.y; j++)
        {
            if (dataPoints[i][j].temperature > maxTemp)
            {
                maxTemp = 300;//dataPoints[i][j].temperature;
            }
            if (dataPoints[i][j].temperature < minTemp)
            {
                minTemp = 200;//dataPoints[i][j].temperature;
            }
        }
    }

    // Color all draw points appropriately.
    for (sf::Uint32 i = 0; i < size.x; i++)
    {
        for (sf::Uint32 j = 0; j < size.y; j++)
        {
            for (sf::Uint32 k = 0; k < 4; k++)
            {
                if (useImage)
                {
                    drawImage.setPixel(i, j, GetHSVtoRGBColor((dataPoints[i][j].temperature - minTemp)/(maxTemp - minTemp)));
                }
                else
                {
                    drawPoints[i*size.y +j].color = GetHSVtoRGBColor((dataPoints[i][j].temperature - minTemp)/(maxTemp - minTemp));
                }
                
            }
        }
    }
    
    if (useImage)
    {
        drawTexture.update(drawImage);
        window.draw(drawSprite);
    }
    else
    {
        window.draw(&drawPoints[0], drawPoints.size(), sf::Points);
    }

    int tempIdx = fileIdx;
    int zeros = 3;
    while (tempIdx >= 10)
    {
        tempIdx /= 10;
        zeros--;
    }

    std::stringstream saveStream;
    saveStream << "C:\\users\\granroth\\Desktop\\ht\\captured"; 
    for (int i= 0; i < zeros; i++)
    {
        saveStream << "0";
    }
    saveStream << fileIdx << ".png";
    //window.capture().saveToFile(saveStream.str());
    ++fileIdx;

}