#pragma once

#include "stdafx.h"

class FpsDisplay
{
    std::deque<sf::Int32> lastTen;
    std::string GetAverageFPS(void);

public:
    void Update(sf::Time& timeDelta);
    std::string GetText(void);
};

