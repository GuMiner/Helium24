#pragma once

#include "stdafx.h"
#include "PhysicsData.h"

class SimDisplay
{
    std::vector<sf::Vertex> drawPoints;
    sf::Vector2u size;
    int fileIdx;

    sf::Color GetHSVtoRGBColor(float h);
    sf::Image drawImage;
    sf::Texture drawTexture;
    sf::Sprite drawSprite;

    bool isRainbow;
public:
    
    static const int SCALE_FACTOR = 3;
    static const int OFFSET_Y = 1;

    SimDisplay();
    void FlipColorScheme(void);
    void Render(sf::RenderWindow& window, std::vector<std::vector<PhysicsData>>& dataPoints);
};

