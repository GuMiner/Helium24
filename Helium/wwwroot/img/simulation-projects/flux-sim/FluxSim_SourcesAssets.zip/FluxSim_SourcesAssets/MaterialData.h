// Holds the material data for one material (iron, concrete, etc).
#pragma once

#include "stdafx.h"
#include "MaterialDataPoint.h"

class MaterialData
{
    std::string name;
    std::vector<MaterialDataPoint> dataPoints;

    bool FindMaterialDataPointRange(float temp, MaterialDataPoint *first, MaterialDataPoint *second);

public:
    bool isValid;

    MaterialData(std::string filename);
    float GetHeatCapacity(float temp);
    float GetThermalConductivity(float temp);
    float GetDensity(float temp);
};

