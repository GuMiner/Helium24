Flux Sim Notes:
Gustave Granroth  05/02/2014

Requires the VS 2012 (x86) redistributable.

See g-cnp.rhcloud.com for program usage information.

Covered under the modified BSD license.
